//
//  Request.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 27/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import Foundation
import RxSwift

class Request {
    
    enum ContentType: String {
        case application_json = "application/json"
    }
    enum Method: String {
        case get = "GET"
        case post = "POST"
    }
    
    func regular(url: String, contentType: ContentType = .application_json, method: Method = .get) -> Observable<Data> {
        return Observable.create { observer in
            
            let session = URLSession.shared
            var request = URLRequest(url: URL(string: url)!)
            
            request.httpMethod = method.rawValue
            request.addValue(contentType.rawValue, forHTTPHeaderField: "Content-Type")
            
            session.dataTask(with: request) { (data, response, error) in
                /// Error
                if let e = error {
                    let error = CustomError(
                        title: e.localizedDescription,
                        description: e.localizedDescription,
                        code: 0
                    )
                    observer.onError(error)
                    observer.onCompleted()
                }
                guard let data = data, let response = response as? HTTPURLResponse, error == nil else { return }
                
                if (200...299).contains(response.statusCode) {
                    observer.onNext(data)
                }
                else {
                    do {
                        let decoder = JSONDecoder()
                        let customErrorJson = try decoder.decode(CustomErrorJson.self, from: data)
                        
                        let error = CustomError(
                            title: customErrorJson.statusMessage,
                            description: customErrorJson.statusMessage,
                            code: customErrorJson.statusCode
                        )
                        print("API_ERROR: url \(url)")
                        print("API_ERROR: statusCode \(response.statusCode)")
                        observer.onError(error)
                    } catch let error {
                        print("JSON_DECODER_API_ERROR: \(error.localizedDescription)")
                        observer.onError(error)
                    }
                }
                
                observer.onCompleted()
            }.resume()
            
            return Disposables.create {
                session.finishTasksAndInvalidate()
            }
        }
    }
    
}

protocol OurErrorProtocol: LocalizedError {

    var title: String { get }
    var code: Int { get }
}

struct CustomError: OurErrorProtocol {
    var title: String
    var code: Int
    var errorDescription: String? { return _description }
    var failureReason: String? { return _description }

    private var _description: String

    init(title: String, description: String = "", code: Int = 0) {
        self.title = title
        self._description = description
        self.code = code
    }
}

struct CustomErrorJson: Codable {
    let statusCode: Int
    let statusMessage: String
    let success: Bool
    
    enum CodingKeys: String, CodingKey {
        case statusCode = "status_code"
        case statusMessage = "status_message"
        case success
    }
}
