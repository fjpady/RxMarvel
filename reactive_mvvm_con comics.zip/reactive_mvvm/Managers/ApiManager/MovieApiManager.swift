//
//  MovieApiManager.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 26/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import Foundation
import RxSwift

class MovieApiManager {
    
    var disposeBag = DisposeBag()
    
    // - Función para obtener el listado de películas populares de la API
    func getPopularMovies() -> Observable<[Movie]> {
        let request = Request()
        
        return Observable.create { observer in
            
            let url = Constants.Movies.popular_movies
            request.regular(url: url)
                .subscribe(
                    onNext: { data in
                        do {
                            let decoder = JSONDecoder()
                            let movies = try decoder.decode(Movies.self, from: data)
                            observer.onNext(movies.listOfMovies)
                        }
                        catch let error {
                            print("API_ERROR: \(error.localizedDescription)")
                            observer.onError(error)
                        }
                    },
                    onError: { error in
                        let ce = CustomError(title: error.localizedDescription)
                        observer.onError(ce)
                    },
                    onCompleted: {
                        observer.onCompleted()
                    }
                )
                .disposed(by: self.disposeBag)
            
            return Disposables.create{}
        }
        
    }
    
    // - Función para obtener el detalle de una película de la API
    func getMovieDetails(_ id: Int) -> Observable<MovieDetails> {
        let request = Request()
        
        return Observable.create { observer in
            
            let url = String(format: Constants.Movies.details_movies, "\(id)")
            request.regular(url: url)
                .subscribe(
                    onNext: { data in
                        do {
                            let decoder = JSONDecoder()
                            let movie = try decoder.decode(MovieDetails.self, from: data)
                            observer.onNext(movie)
                        }
                        catch let error {
                            print("API_ERROR: \(error.localizedDescription)")
                            observer.onError(error)
                        }
                    },
                    onError: { error in
                        observer.onError(error)
                    },
                    onCompleted: {
                        observer.onCompleted()
                    }
                )
                .disposed(by: self.disposeBag)
            
            return Disposables.create{}
        }
        
    }
    
}
