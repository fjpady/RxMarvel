//
//  ComicDetailsView.swift
//  reactivemvvm
//
//  Created by Francisco José Ruiz on 13/11/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import UIKit

class ComicDetailsView: UIViewController {

    //MARK: IBOutlets
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    
    //MARK: Constaints
    @IBOutlet weak var topScrollView: NSLayoutConstraint!
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    
    /*@IBOutlet weak var imageViewHeight: NSLayoutConstraint!
    @IBOutlet weak var titleWidth: NSLayoutConstraint!
    @IBOutlet weak var imageViewWidth: NSLayoutConstraint!*/
    
    
    //MARK: Construct
    static func create() -> ComicDetailsView {
        let vc = ComicDetailsView(nibName: "ComicDetailsView", bundle: nil)
        return vc
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureView()
    }
    
    func configureView() {
        /// Register cell for tableview
        tableView.register(
            UINib(nibName: "ComicHeaderCell", bundle: nil),
            forCellReuseIdentifier: "ComicHeaderCell"
        )
        
        tableView.delegate = self
        tableView.dataSource = self
        
        
        imageView.layer.shadowColor = UIColor.white.cgColor
        imageView.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        imageView.layer.shadowRadius = 10.0
        imageView.layer.shadowOpacity = 1
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewDidLayoutSubviews() {
        topScrollView.constant = -45
    }
    
    @IBAction func dismissTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}

extension ComicDetailsView: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let headerCell = tableView.dequeueReusableCell(withIdentifier: "ComicHeaderCell") as! ComicHeaderCell
        return headerCell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerCell = tableView.dequeueReusableCell(withIdentifier: "ComicHeaderCell") as! ComicHeaderCell
        return headerCell
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForHeaderInSection section: Int) -> CGFloat {
        return 100.0
    }
    func tableView(_ tableView: UITableView, estimatedHeightForFooterInSection section: Int) -> CGFloat {
        return 100.0
    }

    
}
