//
//  ComicHeaderCell.swift
//  reactivemvvm
//
//  Created by Francisco José Ruiz on 14/11/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import UIKit

class ComicHeaderCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
