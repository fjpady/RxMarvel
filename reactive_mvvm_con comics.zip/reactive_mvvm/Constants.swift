//
//  Constants.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 26/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import Foundation

/// global locale
var locale = "es"

struct Constants {
    
    /// Global url vars
    struct Storyboards {
        static let Main = "Main"
    }
    
    /// Global url vars
    struct global_urls {
        static let `protocol` = "https://%@"
        static let url_name = "api.themoviedb.org"
    }
    
    struct api_keys {
        static let v3 = "0aaf16ff795891332e506295fa38a1db"
        static let v4 = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwYWFmMTZmZjc5NTg5MTMzMmU1MDYyOTVmYTM4YTFkYiIsInN1YiI6IjVmOTZhZDZkNmMwYjM2MDAzMzBiNTQ0NSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.CI006b6vZyIAHVEcoEMe91_5dBLZIO4aWYG7wjAnC84"
    }
    
    
    /// API vars
    static let api_url = String(format: Constants.global_urls.protocol, Constants.global_urls.url_name)
    static let api_key = "?api_key=\(Constants.api_keys.v3)"
    
    /// Login api vars
    struct Login {
        static let user_login_endpoint = "\(Constants.api_url)/\(locale)/users/auth" /// unused
    }
    
    struct Movies {
        static let popular_movies = "\(Constants.api_url)/3/movie/popular\(Constants.api_key)"
        static let details_movies = "\(Constants.api_url)/3/movie/%@\(Constants.api_key)"
        static let images = "https://image.tmdb.org/t/p/w200"
    }
    
}
