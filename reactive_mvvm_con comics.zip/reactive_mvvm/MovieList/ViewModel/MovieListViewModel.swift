//
//  MovieListViewModel.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 26/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

protocol MovieListViewModelProtocol {
    func transform(_ input: MovieListViewModel.Input) -> MovieListViewModel.Output
    func getData() -> Void
    var output: MovieListViewModel.Output! { get }
    var movies: [Movie] { get set }
}

class MovieListViewModel: MovieListViewModelProtocol {
    
    //MARK: Managers
    private var apiManager = MovieApiManager()
    
    //MARK: Properties
    var movies = [Movie]()
    
    //MARK: Rx
    private let disposeBag = DisposeBag()
    
    //MARK: Rx Subjects
    internal let movieFetchedSubject = PublishSubject<[Movie]>()
    internal let errorFetchedSubject = PublishSubject<CustomError>()
    
    //MARK: Input
    struct Input {
        /// String del searchbar para filtrar en local
        let filteredText: Observable<String>
        
        /// Recargar los datos
        let reloadData: Observable<Void>
    }
    
    //MARK: output
    struct Output {
        /// Texto del filtro
        let filter: Void
        
        /// Listado de películas filtradas o fin filtrar
        let movies: Driver<[Movie]>
        
        /// Error
        let error: Driver<CustomError>
    }
    
    private(set) var input: Input!
    private(set) var output: Output!
    
    //MARK: Transform
    func transform(_ input: Input) -> Output {
        self.input = input
        self.output = Output(
            filter: filterText(input),
            movies: moviesFetch,
            error: ErrorFetch
        )
        
        /// Subscribe reload data for Refresh control or fetch data
        input.reloadData.subscribe(
            onNext: {
                self.getData()
        }).disposed(by: disposeBag)
        
        return output
    }
    
    
    //MARK: Methods
    func getData() {
        apiManager.getPopularMovies()
            .subscribe(onNext: { movies in
                self.movies = movies
                self.movieFetchedSubject.asObserver().onNext(movies)
                
            }, onError: { error in
                self.errorFetchedSubject.asObserver().onNext(error as! CustomError)
                
            }).disposed(by: disposeBag)
    }
    
}


//MARK: Output
extension MovieListViewModel {
    func filterText(_ input: Input) {
        input.filteredText.subscribe(
            onNext: { text in
                if text.count == 0 {
                    self.movieFetchedSubject.asObserver().onNext(self.movies)
                    return
                }
                let filteredMovies = self.movies.filter({ movie in
                    return movie.title.contains(text)
                })
                self.movieFetchedSubject.asObserver().onNext(filteredMovies)
                
        }).disposed(by: disposeBag)
    }
    
    var moviesFetch: Driver<[Movie]> {
        movieFetchedSubject.asDriver(onErrorDriveWith: Driver.never())
    }
    
    var ErrorFetch: Driver<CustomError> {
        errorFetchedSubject.asDriver(onErrorDriveWith: Driver.never())
    }
}
