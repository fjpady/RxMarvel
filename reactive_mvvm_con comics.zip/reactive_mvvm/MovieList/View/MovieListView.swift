//
//  MovieListView.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 26/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class MovieListView: UIViewController {

    //MARK: Construct
    static func create(viewModel: MovieListViewModelProtocol) -> MovieListView {
        let vc = UIStoryboard(
            name: Constants.Storyboards.Main,
            bundle: nil
        ).instantiateViewController(
            withIdentifier: "MovieListView"
        ) as! MovieListView
        vc.viewModel = viewModel
        return vc
    }
    
    //MARK: IBOutlet
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var tableView: UITableView!
    private lazy var searchController: UISearchController = ({
        let controller = UISearchController(searchResultsController: nil)
        controller.hidesNavigationBarDuringPresentation = true
        controller.obscuresBackgroundDuringPresentation = false
        controller.searchBar.sizeToFit()
        controller.searchBar.barStyle = .black
        controller.searchBar.backgroundColor = .clear
        controller.searchBar.placeholder = Localizable.MovieListView.search_bar.localized
        return controller
    })()
    
    private lazy var refreshControl = UIRefreshControl()
    
    private lazy var movieDetailsView = MovieDetailsView()
    
    
    //MARK: Viewmodel
    private var viewModel: MovieListViewModelProtocol!
    
    //MARK: Properties
    private var movies = [Movie]()
    private var filteredMovies = [Movie]()
    
    //MARK: Managers
    private var alertManager = AlertManager()
    
    //MARK: Rx
    private var disposeBag = DisposeBag()
    
    
    //MARK: UIViewController
    override func viewDidLoad() {
        super.viewDidLoad()
        translate()
        configureView()
        setupBindings()
        viewModel.getData()
    }
    
    private func translate() {
        titleLabel.text = Localizable.MovieListView.title.localized
    }
    
    private func configureView() {
        /// tableview configuration
        tableView.rx.setDelegate(self).disposed(by: disposeBag)
        
        /// Register cell for tableview
        tableView.register(
            UINib(nibName: "MovieCell", bundle: nil),
            forCellReuseIdentifier: "MovieCell"
        )
        
        /// Add a search controller
        addSearchController()
        
        /// Add a refresh control
        addPullToRefresh()
    }
    
    
    private func addPullToRefresh() {
        /// End refreshing when appears
        refreshControl.rx
            .controlEvent(.valueChanged)
            .subscribe(onNext: { [weak self] in
                self?.refreshControl.endRefreshing()
            }).disposed(by: disposeBag)
        
        /// Add pull to refresh
        tableView.addSubview(refreshControl)
    }
    
    private func addSearchController() {
        let searchBar = searchController.searchBar
        searchController.delegate = self
        tableView.tableHeaderView = searchBar
        tableView.contentOffset = CGPoint(x: 0, y: searchBar.frame.size.height)
    }
    
    private func setupBindings() {
        /// Set up viewmodel output
        let output = viewModel.transform(
            MovieListViewModel.Input(
                filteredText: searchController.searchBar.rx.text.orEmpty.asObservable(),
                reloadData: refreshControl.rx.controlEvent(.valueChanged).asObservable()
            )
        )
        
        /// On fetch data
        onMoviesFetched(output)
        
        /// On handle error
        onHandleError(output)
    }
    
    /// On fetch Data
    private func onMoviesFetched(_ output: MovieListViewModel.Output) {
        /// On fetch
        output.movies.asObservable().bind(to: tableView.rx.items(cellIdentifier: "MovieCell", cellType: MovieCell.self)) { row, item, cell in
            cell.setCell(item)
        }.disposed(by: disposeBag)
        
        /// On tap
        /*tableView.rx.modelSelected(Movie.self).subscribe(
            onNext: { movie in
                self.presentDetails(movie)
        }).disposed(by: disposeBag)*/
        
        /// On tap (esta forma es menos fina para una solución tan simple pero la necesito para hacer deselect de la fila)
        Observable
        .zip(tableView.rx.itemSelected, tableView.rx.modelSelected(Movie.self))
        .bind { [unowned self] indexPath, movie in
            self.tableView.deselectRow(at: indexPath, animated: true)
            self.presentDetails(movie)
        }
        .disposed(by: disposeBag)
    }
    
    /// On handle Error
    private func onHandleError(_ output: MovieListViewModel.Output) {
        output.error.drive(
            onNext: {
                self.alertManager.showWarning(parentView: self.view, message: $0.title)
        }).disposed(by: disposeBag)
    }
    
    /// Present Movie details
    private func presentDetails(_ movie: Movie) {
        searchController.isActive = false
        movieDetailsView = MovieDetailsView.create(viewModel: MovieDetailsViewModel(movie: movie))
        movieDetailsView.modalPresentationStyle = .formSheet
        //self.present(movieDetailsView, animated: true, completion: nil)
        
        let vc = ComicDetailsView.create()
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
        //self.navigationController?.pushViewController(vc, animated: true)
    }

}

//MARK: UITableViewDelegate
extension MovieListView: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 185.0
    }
}

//MARK: UISearchControllerDelegate
extension MovieListView: UISearchControllerDelegate {
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchController.isActive = false
    }
}
