//
//  MovieCell.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 26/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import UIKit

class MovieCell: UITableViewCell {

    @IBOutlet weak var movieImageView: UIImageView!
    @IBOutlet weak var titleName: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionName: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        translate()
        configureView()
    }
    
    private func translate() {
        titleName.text = Localizable.MovieCell.title.localized
        descriptionName.text = Localizable.MovieCell.description.localized
    }
    
    private func configureView() {
        self.movieImageView.image = nil
        self.movieImageView.layer.cornerRadius = 10
        self.movieImageView.clipsToBounds = true
    }
    
    func setCell(_ movie: Movie) {
        titleLabel.text = movie.title
        descriptionLabel.text = movie.sinopsis
        
        if let filename = movie.image {
            let url = "\(Constants.Movies.images)\(filename)"
            movieImageView.imageFromServer(
                url: url,
                placeholder: UIImage(named: "ic_placeholder")
            )
        }
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
