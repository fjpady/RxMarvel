//
//  Movie.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 26/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import Foundation

class Movies: Codable {
    let listOfMovies: [Movie]
    
    enum CodingKeys: String, CodingKey {
        case listOfMovies = "results"
    }
}

class Movie: Codable, Equatable {
    let title: String
    let popularity: Double
    let id: Int
    let voteCount: Int
    let originalTitle: String
    let sinopsis: String
    let releaseDate: String
    let image: String?
    
    enum CodingKeys: String, CodingKey {
        case title
        case popularity
        case id
        case voteCount = "vote_count"
        case originalTitle = "original_title"
        case sinopsis = "overview"
        case releaseDate = "release_date"
        case image = "poster_path"
    }
    
    
    static func ==(lhs: Movie, rhs: Movie) -> Bool {
        return lhs.id == rhs.id && lhs.originalTitle == rhs.originalTitle
    }
    
}
