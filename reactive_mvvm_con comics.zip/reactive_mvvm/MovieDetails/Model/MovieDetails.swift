//
//  MovieDetails.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 27/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import Foundation

class MovieDetails: Movie {
    
    let homepage: String
    let voteAverage: Double
    let imdb_id: String
    //let genres: [Genre]
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.homepage = try container.decode(String.self, forKey: .homepage)
        self.voteAverage = try container.decode(Double.self, forKey: .voteAverage)
        self.imdb_id = try container.decode(String.self, forKey: .imdb_id)
        
        //var genresArray = try container.nestedUnkeyedContainer(forKey: .genres)
        
        try super.init(from: decoder)
    }
    
    enum CodingKeys: String, CodingKey {
        case homepage
        case voteAverage = "vote_average"
        case imdb_id
        case genres
    }
}

class Genres: Codable {
    let listOfGenres: [Genre]
    
    enum CodingKeys: String, CodingKey {
        case listOfGenres = "genres"
    }
}

// MARK: - Genre
class Genre: Codable {
    let id: Int
    let name: String

    enum CodingKeys: String, CodingKey {
        case id
        case name
    }
    
    init(id: Int, name: String) {
        self.id = id
        self.name = name
    }
}
