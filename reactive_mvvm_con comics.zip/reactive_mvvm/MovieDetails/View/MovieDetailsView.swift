//
//  MovieDetailsView.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 27/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import UIKit
import RxSwift

class MovieDetailsView: UIViewController {

    //MARK: Construct
    static func create(viewModel: MovieDetailsViewModelProtocol) -> MovieDetailsView {
        let vc = MovieDetailsView(nibName: "MovieDetailsView", bundle: nil)
        vc.viewModel = viewModel
        return vc
    }
    
    //MARK: IBOutlets
    @IBOutlet private weak var titleControllerName: UILabel!
    @IBOutlet private weak var imageView: UIImageView!
    @IBOutlet private weak var titleName: UILabel!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var yearName: UILabel!
    @IBOutlet private weak var yearLabel: UILabel!
    @IBOutlet private weak var genreName: UILabel!
    @IBOutlet private weak var genreLabel: UILabel!
    @IBOutlet private weak var descriptionName: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    
    
    //MARK: Properties
    
    
    //MARK: ViewModel
    var viewModel: MovieDetailsViewModelProtocol!
    
    
    //MARK: Rx
    var disposeBag = DisposeBag()
    
    
    //MARK: UIViewController
    override func viewDidLoad() {
        super.viewDidLoad()
        translate()
        configureView()
        getData()
    }
    
    private func getData() {
        viewModel.getMovieDetails()
        .subscribe(
            onNext: { movieDetails in
                self.showMovieData(movieDetails)
            },
            onError: { error in
                
            }
        ).disposed(by: disposeBag)
    }
    
    private func translate() {
        titleName.text = Localizable.MovieDetailsView.title.localized
        yearName.text = Localizable.MovieDetailsView.year.localized
        genreName.text = Localizable.MovieDetailsView.genre.localized
        descriptionName.text = Localizable.MovieDetailsView.description.localized
    }
    
    private func configureView() {
        /// ImageView
        imageView.layer.cornerRadius = 10
        imageView.clipsToBounds = true
    }
    

    //MARK: Methods
    private func showMovieData(_ movie: MovieDetails) {
        DispatchQueue.main.async {
            self.titleLabel.text = movie.title
            self.yearLabel.text = movie.releaseDate
            self.genreLabel.text = movie.originalTitle
            self.descriptionLabel.text = movie.sinopsis
            if let filename = movie.image {
                let url = "\(Constants.Movies.images)\(filename)"
                self.imageView.imageFromServer(
                    url: url,
                    placeholder: UIImage(named: "ic_placeholder")
                )
            }
        }
    }
    
    //MARK: IBActions
    @IBAction func backTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    


}
