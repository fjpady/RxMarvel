//
//  MovieDetailsViewModel.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 27/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import Foundation
import RxSwift

protocol MovieDetailsViewModelProtocol {
    init(movie: Movie)
    func getMovieDetails() -> Observable<MovieDetails>
}

class MovieDetailsViewModel: MovieDetailsViewModelProtocol {
    
    //MARK: Properties
    var apiManager = MovieApiManager()
    var movie: Movie!
    
    required init(movie: Movie) {
        self.movie = movie
    }
    
    //MARK: Methods
    func getMovieDetails() -> Observable<MovieDetails> {
        return apiManager.getMovieDetails(movie.id)
    }
    
}
