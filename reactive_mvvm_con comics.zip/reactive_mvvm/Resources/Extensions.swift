//
//  Extensions.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 27/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import UIKit

//MARK: Extensions for UIImageView
extension UIImageView {
    
    /// Función para obtener una imagen de internet
    func imageFromServer(url: String, placeholder: UIImage? = nil) {
        if self.image == nil, let placeholder = placeholder {
            self.image = placeholder
        }
        
        URLSession.shared.dataTask(with: URL(string: url)!) { (data, response, error) in
            if error != nil { return }
            
            DispatchQueue.main.async {
                guard let data = data else { return }
                self.image = UIImage(data: data)
            }
        }.resume()
    }
    
}

//MARK: Extensions for String
extension String {
    /// Check valid mail
    func isValidEmail() -> Bool {
        let regex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        return doRegex(regex)
    }
    
    /// Check password
    func isValidPassword() -> Bool {
        let regex = "^[a-zA-Z0-9._%+-]{6,}$"
        return doRegex(regex)
    }
    
    private func doRegex(_ regex: String) -> Bool {
        if self.count == 0 { return false }
        let r = NSPredicate(format:"SELF MATCHES %@", regex)
        return r.evaluate(with: self)
    }
}
