//
//  Localizable.swift
//  reactive_mvvm
//
//  Created by Francisco José Ruiz on 26/10/2020.
//  Copyright © 2020 Francisco José Ruiz. All rights reserved.
//

import Foundation

enum Localizable {

    //MARK: Fields
    enum Common: String, LocalizableDelegate {
        case aceptar = "Common.aceptar"
        case editar = "Common.editar"
        case cancelar = "Common.cancelar"
        case ok = "Common.ok"
        case salir = "Common.salir"
        case finalizar = "Common.finalizar"
        case siguiente = "Common.siguiente"
        case aviso = "Common.aviso"
        case continuee = "Common.continue"
        case yes_continue = "Common.yes_continue"
        case yes_delete = "Common.yes_delete"
        case volver = "Common.volver"
        case ultima = "Common.ultima"
        case proxima = "Common.proxima"
        case save = "Common.guardar"
        case fecha = "Common.fecha"
        case add = "Common.add"
        case cerrar = "Common.Cerrar"
        case yes = "Common.yes"
        case no = "Common.no"
        case send = "Common.send"
        
        case invalid_password = "Common.invalid_password"
        case invalid_email = "Common.invalid_email"
        
        case valid_password = "Common.valid_password"
        case valid_email = "Common.valid_email"
        case fill_fields = "Common.fill_fields"
        case no_internet_connection = "Common.no_internet_connection"
    }
    
    
    enum LoginView: String, LocalizableDelegate {
        case title = "LoginView.title"
        case mail_label = "LoginView.mail_label"
        case mail_placeholder = "LoginView.mail_placeholder"
        case password_label = "LoginView.password_label"
        case password_placeholder = "LoginView.password_placeholder"
        case login_button = "LoginView.login_button"
        case hint_connection = "LoginView.hint_connection"
        
    }
    
    enum MovieDetailsView: String, LocalizableDelegate {
        case title = "MovieDetailsView.title"
        case year = "MovieDetailsView.year"
        case genre = "MovieDetailsView.genre"
        case description = "MovieDetailsView.description"
    }
    
    
    enum MovieListView: String, LocalizableDelegate {
        case title = "MovieListView.title"
        case search_bar = "MovieListView.search_bar"
    }
    
    
    enum SplashView: String, LocalizableDelegate {
        case title = "SplashView.title"
        case list = "SplashView.list"
        case `continue` = "SplashView.continue"
    }
    
    enum MovieCell: String, LocalizableDelegate {
        case title = "MovieCell.title"
        case `description` = "MovieCell.description"
    }
}


protocol LocalizableDelegate {
    var rawValue: String { get }    //localize key
    var table: String? { get }
    var localized: String { get }
}
extension LocalizableDelegate {

    func localized(_ obj: Any?) -> String {
        var translation: String! = ""
        if obj is Int {
            let txt = Bundle.main.localizedString(forKey: rawValue, value: nil, table: table)
            translation = String(format: txt, obj as! Int)
        }
        if obj is String {
            let txt = Bundle.main.localizedString(forKey: rawValue, value: nil, table: table)
            translation = String(format: txt, obj as! String)
        }
        return translation
    }
    
    //returns a localized value by specified key located in the specified table
    var localized: String {
        return Bundle.main.localizedString(forKey: rawValue, value: nil, table: table)
    }

    // file name, where to find the localized key
    // by default is the Localizable.string table
    var table: String? {
        return nil
    }
}

